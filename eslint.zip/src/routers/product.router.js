import express from 'express';

const router = express.Router();

router.get('/', (req, res) => {
  res.json({ message: 'Get all products' });
});

router.get('/:id', (req, res) => {
  res.json({ message: 'Get a product by id' });
});

router.post('/', (req, res) => {
  res.json({ message: 'Post product' });
});

router.put('/:id', (req, res) => {
  res.json({ message: 'Update a product by id' });
});

router.delete('/:id', (req, res) => {
  res.json({ message: 'delete a product' });
});

export default router;
