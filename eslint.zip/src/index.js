import { db } from './config/db.js';
import express from 'express';
import productRouter from './routers/product.router.js';
import { env } from './config/env.js';

const app = express();

app.use(express.json());

// Establish connection to database
db.connect((err) => {
  if (err) {
    console.log(
      `Your database not connected. Error message: ${err?.sqlMessage}`,
    );
    return false;
  }
  console.log('Your database connected successfully !!!');
  return true;
});

//Definition of the different endpoints of our application
app.use('/api/products', productRouter);

// handling of urls not found
app.use('*', (req, res, next) => {
  console.log('====================================');
  console.log('Resource not found');
  console.log('====================================');
  next();
});

app.listen(env.port, env.hostName, () => {
  console.log('====================================');
  console.log(
    `Our application ${env.appName} running on port: http://${env.hostName}:${env.port}`,
  );
  console.log('====================================');
});
