import mysql from 'mysql2';
import { env } from './env.js';

export const db = mysql.createConnection({
  host: env.dbHost,
  user: env.dbUser,
  database: env.dbName,
  password: env.dbPassword,
});
